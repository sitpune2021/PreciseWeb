
<?php $__env->startSection('content'); ?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">View Projects</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="buttons-datatables" class="display table table-bordered" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>Project Name</th>
                                            <th>Project Code</th>
                                            <th>Work Order No.</th>
                                            <th>Start Date</th>
                                            <th>End Date</th>
                                            <th>Quantity</th>
                                            <th width="12%">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                                <td><?php echo e($project->name); ?></td>
                                                <td><?php echo e($project->code); ?></td>
                                                <td><?php echo e($project->work_order_no); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($project->StartDate)->format('d-m-Y')); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($project->EndDate)->format('d-m-Y')); ?></td>
                                                <td><?php echo e($project->qty); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('editProject', base64_encode($project->id))); ?>">
                                                        <button type="button" class="btn btn-success btn-icon waves-effect waves-light">
                                                            <i class="ri-pencil-fill align-bottom"></i>
                                                        </button>
                                                    </a>

                                                    <button type="button" class="btn btn-primary btn-icon waves-effect waves-light">
                                                        <i class="ri-eye-fill align-bottom"></i>
                                                    </button>

                                                    <a href="#">
                                                        <button type="button" class="btn btn-danger btn-icon waves-effect waves-light">
                                                            <i class="ri-delete-bin-fill align-bottom"></i>
                                                        </button>
                                                    </a>
                                                </td>
                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end row-->

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PreciseEng2025\resources\views/Project/view.blade.php ENDPATH**/ ?>
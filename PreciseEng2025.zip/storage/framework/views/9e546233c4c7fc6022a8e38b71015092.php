
<?php $__env->startSection('content'); ?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-xxl-12">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="mb-0 flex-grow-1">
                                <?php echo e(isset($customer) ? 'Edit Customer' : 'Add Customer'); ?>

                            </h4>
                            
                        </div><!-- end card header -->

                        <div class="card-body">
                           
                            <div class="live-preview">
                                <form action="<?php echo e(isset($customer) ? route('updateCustomer', base64_encode($customer->id)) : route('storeCustomer')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                    <?php if(isset($customer)): ?>
                                        <?php echo method_field('PUT'); ?>
                                        <!-- //<?php echo method_field('DELETE'); ?> -->
                                    <?php endif; ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="name" class="form-label">Customer Name <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" placeholder="Customer Name" id="name" name="name" value="<?php echo e(old('name', $customer->name ?? '')); ?>">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-red"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                         <!--end col-->
                                       <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="code" class="form-label">Customer Code <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" placeholder="Customer Code" id="code" name="code" value="<?php echo e(old('code', $customer->code ?? '')); ?>">
                                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-red"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <!--end col-->
                                                                                
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="email_id" class="form-label">Email Id</label>
                                                <input type="email" class="form-control" placeholder="Email Id" id="email_id" name="email_id" value="<?php echo e(old('email_id', $customer->email_id ?? '')); ?>">
                                            
                                            </div>
                                        </div>
                                        <!--end col-->
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="contact_person" class="form-label">Contact Person <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" placeholder="Contact Person<" id="contact_person" name="contact_person" value="<?php echo e(old('contact_person', $customer->contact_person ?? '')); ?>">
                                            <?php $__errorArgs = ['contact_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-red"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        <!--end col-->
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="phone_no" class="form-label">Phone Number <span class="mandatory">*</span></label>
                                                <input type="tel" class="form-control" placeholder="Phone Number" id="phone_no" name="phone_no" value="<?php echo e(old('phone_no', $customer->phone_no ?? '')); ?>">
                                            <?php $__errorArgs = ['phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-red"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <!--end col-->
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="gst_no" class="form-label">GST Number <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" placeholder="GST Number" id="gst_no" name="gst_no" value="<?php echo e(old('gst_no', $customer->gst_no ?? '')); ?>">
                                            <?php $__errorArgs = ['gst_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-red"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <!--end col-->
                                        
                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <label for="address" class="form-label">Address <span class="mandatory">*</span></label>
                                                <textarea class="form-control" placeholder="Address..." id="address" name="address"><?php echo e(old('address', $customer->address ?? '')); ?></textarea>
                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-red"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <!--end col-->
                                        
                                        <div class="col-lg-12">
                                            <div class="text-end">
                                                <button type="submit" class="btn btn-primary">
                                                    <?php echo e(isset($customer) ? 'Update' : 'Submit'); ?>

                                                </button>
                                                &nbsp;
                                                <?php if(isset($customer)): ?>
                                                <a href="<?php echo e(route('ViewCustomer')); ?>" class="btn btn-info">Cancel</a>
                                                    
                                                <?php else: ?>
                                                    <button type="reset" class="btn btn-info">Reset</button>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                        <!--end col-->
                                    </div>
                                    <!--end row-->
                                </form>
                            </div>
                           
                        </div>
                    </div>
                </div> <!-- end col -->

                
            </div>
            <!--end row-->

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PreciseEng2025\resources\views/Customer/add.blade.php ENDPATH**/ ?>
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('machines', function (Blueprint $table) {
            $table->id('MachineRecordId'); 
            $table->string('MachineName', 50);
            $table->unsignedBigInteger('SetupId'); 
            $table->string('OperatorName', 100)->nullable();
            $table->dateTime('OperationStart')->nullable();
            $table->dateTime('OperationEnd')->nullable();
            $table->text('Remarks')->nullable();
            $table->timestamps();

 
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('machines');
    }
};


<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Machine extends Model
{
    protected $primaryKey = 'MachineRecordId';  
    public $incrementing = true;                
    protected $keyType = 'int';    

    protected $fillable = [
        'MachineName',
        'SetupId',
        'OperatorName',
        'OperationStart',
        'OperationEnd',
        'Remarks',
    ];
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Project;

class ProjectController extends Controller
{
    /**
     * Show the form to add a project.
     */
    public function AddProject()
    {
        return view('Project.add');
    }

    /**
     * Store a new project in the database.
     */
    public function storeProject(Request $request)
    {
        $validated = $request->validate([
         
            'name'           => 'required|string|max:255',
            'code'           => 'required|string|max:255|unique:projects,code',
            'description'    => 'nullable|string',
            'work_order_no'  => 'required|string|max:255',
            'qty'            => 'required|integer',
            'StartDate'      => 'nullable|date',
            'EndDate'        => 'nullable|date|after_or_equal:StartDate',
        ]);

        Project::create([
    
            'name'           => $request->input('name'),
            'code'           => $request->input('code'),
            'description'    => $request->input('description'),
            'work_order_no'  => $request->input('work_order_no'),
            'qty'            => $request->input('qty'),
            'StartDate'      => $request->input('StartDate'),
            'EndDate'        => $request->input('EndDate'),
        ]);

        return redirect()->route('ViewProject')->with('success', 'Project added successfully.');
    }

    /**
     * View all projects.
     */
    public function ViewProject()
    {
        $projects = Project::all();
        return view('Project.view', compact('projects'));
    }

    /**
     * Show the edit form for a project.
     */
    public function edit(string $encryptedId)
    {
        try {
            $id = base64_decode($encryptedId);
            $project = Project::findOrFail($id);
            return view('Project.add', compact('project'));
        } catch (\Exception $e) {
            abort(404);
        }
    }

    /**
     * Update an existing project.
     */
    public function update(Request $request, string $encryptedId)
    {
        $id = base64_decode($encryptedId);
        $project = Project::findOrFail($id);

        $validated = $request->validate([
     
            'name'           => 'required|string|max:255',
            'code'           => 'required|string|max:255|unique:projects,code,' . $project->id,
            'description'    => 'nullable|string',
            'work_order_no'  => 'required|string|max:255',
            'qty'            => 'required|integer|min:10',
            'StartDate'      => 'nullable|date',
            'EndDate'        => 'nullable|date|after_or_equal:StartDate',
        ]);

        $project->update($validated);

        return redirect()->route('ViewProject')->with('success', 'Project updated successfully.');
    }

    /**
     * Delete a project (you can complete this method as needed).
     */
    public function destroy(string $id)
    {
        $id = base64_decode($id);
        $project = Project::findOrFail($id);
        $project->delete();

        return redirect()->route('ViewProject')->with('success', 'Project deleted successfully.');
    }
}

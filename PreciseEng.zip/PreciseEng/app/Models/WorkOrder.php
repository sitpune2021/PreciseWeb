<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WorkOrder extends Model
{
    protected $fillable = [
        'work_order_no',
        'entry_code',
        'part',
        'date',
        'part_code',
        'part_description',
        'dimeter',
        'length',
        'width',
        'height',
        'exp_time',
        'quantity',
    ];
}

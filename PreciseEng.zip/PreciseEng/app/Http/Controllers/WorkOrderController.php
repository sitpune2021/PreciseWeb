<?php

namespace App\Http\Controllers;

use App\Models\WorkOrder;


use Illuminate\Http\Request;

class WorkOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function AddWorkOrder()
    {
        return view('WorkOrder.add');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function ViewWorkOrder()
    {
        $workorders = WorkOrder::all();
        return view('WorkOrder.view', compact('workorders'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function storeWorkEntry(Request $request)
    {
        $request->validate([
            'work_order_no'      => 'required|string|max:100',
            // 'entry_code'         => 'required|string|unique:work_orders,entry_code',
            'part'               => 'required|string|max:100',
            'date'               => 'required|date',
            'part_code'          => 'required|string|max:100',
            'part_description'   => 'required|string|max:1000',
            'dimeter'            => 'required|string|max:50',
            'length'             => 'required|string|max:50',
            'width'              => 'required|string|max:50',
            'height'             => 'required|string|max:50',
            'exp_time'           => 'required|date_format:H:i',
            'quantity'           => 'required|integer|min:1',
        ]);

        WorkOrder::create([
            'work_order_no'      => $request->work_order_no,
            // 'entry_code'         => $request->entry_code,
            'part'               => $request->part,
            'date'               => $request->date,
            'part_code'          => $request->part_code,
            'part_description'   => $request->part_description,
            'dimeter'            => $request->dimeter,
            'length'             => $request->length,
            'width'              => $request->width,
            'height'             => $request->height,
            'exp_time'           => $request->exp_time,
            'quantity'           => $request->quantity,
        ]);

        return redirect()->route('ViewWorkEntry')->with('success', 'Work Entry created successfully.');
    }


    /**
     * Display the specified resource.
     */
    public function edit(string $encryptedId)
    {
        try {
            $id = base64_decode($encryptedId);
            $workorder = WorkOrder::findOrFail($id);
            return view('WorkOrder.add', compact('workorder'));
        } catch (\Exception $wo) {
            abort(404);
        }
    }

    public function update(Request $request, string $encryptedId)
    {
        $id = base64_decode($encryptedId);

        $request->validate([
            'work_order_no'      => 'required|string|max:100',
            'entry_code'         => 'required|string|max:100|unique:work_orders,entry_code,' . $id,
            'part'               => 'required|string|max:100',
            'date'               => 'required|date',
            'part_code'          => 'required|string|max:100',
            'part_description'   => 'required|string|max:1000',
            'dimeter'            => 'required|string|max:50',
            'length'             => 'required|string|max:50',
            'width'              => 'required|string|max:50',
            'height'             => 'required|string|max:50',
            'exp_time'           => 'required|date_format:H:i',
            'quantity'           => 'required|integer|min:1',
        ]);

        $workOrder = WorkOrder::findOrFail($id);

        $workOrder->work_order_no     = $request->work_order_no;
        $workOrder->entry_code        = $request->entry_code;
        $workOrder->part              = $request->part;
        $workOrder->date              = $request->date;
        $workOrder->part_code         = $request->part_code;
        $workOrder->part_description  = $request->part_description;
        $workOrder->dimeter           = $request->dimeter;
        $workOrder->length            = $request->length;
        $workOrder->width             = $request->width;
        $workOrder->height            = $request->height;
        $workOrder->exp_time          = $request->exp_time;
        $workOrder->quantity          = $request->quantity;

        $workOrder->save();

        return redirect()->route('ViewWorkOrder')->with('success', 'Work Entry updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}

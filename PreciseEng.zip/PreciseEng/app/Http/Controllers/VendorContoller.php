<?php

namespace App\Http\Controllers;

use App\Models\Vendor;

use Illuminate\Http\Request;

class VendorContoller extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function AddVendor()
    {
        return view('Vendor.add');
    }



    /**
     * Store a newly created resource in storage.
     */
    public function storeVendor(Request $request)
    {
        $request->validate([
            'vendor_name'     => 'required|string|max:255',
            'vendor_code'     => 'required|string|max:100|unique:vendors,vendor_code',
            'contact_person'  => 'required|string|max:255',
            'gst_no'          => 'required|string|max:20',
            'status'          => 'required|in:Active,Inactive',
            'phone_no'        => 'required|digits_between:10,15',
            'email_id'        => 'nullable|email|max:255',
            'address'         => 'required|string|max:500',
        ]);

        Vendor::create([
            'vendor_name'    => $request->vendor_name,
            'vendor_code'    => $request->vendor_code,
            'contact_person' => $request->contact_person,
            'gst_no'         => $request->gst_no,
            'status'         => $request->status,
            'phone_no'       => $request->phone_no,
            'email_id'       => $request->email_id,
            'address'        => $request->address,
        ]);

        return redirect()->route('ViewVendor')->with('success', 'Vendor created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function ViewVendor()
    {
        $vendors = Vendor::all();
        return view('Vendor.view', compact('vendors'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $encryptedId)
    {

        try {
            $id = base64_decode($encryptedId);
            $vendor = Vendor::findOrFail($id);
            return view('Vendor.add', compact('vendor'));
        } catch (\Exception $vendor) {
            abort(404);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $encryptedId)
    {
        try {
            $id = base64_decode($encryptedId);

            $request->validate([
                'vendor_name'     => 'required|string|max:255',
                'vendor_code'     => 'required|string|max:100|unique:vendors,vendor_code',
                'contact_person'  => 'required|string|max:255',
                'gst_no'          => 'required|string|max:20',
                'status'          => 'required|in:Active,Inactive',
                'phone_no'        => 'required|digits_between:10,15',
                'email_id'        => 'nullable|email|max:255',
                'address'         => 'required|string|max:500',
            ]);

            $vendor = Vendor::findOrFail($id);

            $vendor->vendor_name    = $request->vendor_name;
            $vendor->vendor_code    = $request->vendor_code;
            $vendor->contact_person = $request->contact_person;
            $vendor->phone_no       = $request->phone_no;
            $vendor->email_id       = $request->email_id;
            $vendor->gst_no         = $request->gst_no;
            $vendor->address        = $request->address;
            $vendor->status         = $request->status;

            $vendor->save();

            return redirect()->route('ViewVendor')->with('success', 'Vendor updated successfully.');
        } catch (\Exception $vendor) {
            abort(404);
        }
    }




    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}

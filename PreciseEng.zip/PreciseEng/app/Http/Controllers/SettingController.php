<?php

namespace App\Http\Controllers;
use App\Models\Setting;


use Illuminate\Http\Request;

class SettingController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function AddSetting()
    {
        $settings = Setting::latest()->get(); 
         return view('Setting.add', compact('settings'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function storeSetting(Request $request)
    {
         $request->validate([
        'setting_name' => 'required|string|max:255',
    ]);

    Setting::create([
        'setting_name' => $request->setting_name,
    ]);
    return redirect()->route('AddSetting')->with('success', 'Setting added successfully');

        
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function editSetting(string $id)
    {
        
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
    
      public function updateStatus(Request $request)
    {
        $setting = Setting::findOrFail($request->id);

        $setting->status = $request->has('status') ? 1 : 0 ;
        $setting->save();

        return back()->with('success', 'Status updated!');
    }
}

<?php

namespace App\Http\Controllers;
use App\Models\Operator;


use Illuminate\Http\Request;

class OperatorController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function AddOperator()
    {
         $operators = Operator::latest()->get(); 
         return view('Operator.add', compact('operators'));
     
    }

    /**
     * Store a newly created resource in storage.
     */
   public function storeOperator(Request $request)
{
    $request->validate([
        'operator_name' => 'required|string|max:255',
    ]);

    Operator::create([
        'operator_name' => $request->operator_name,
    ]);

    return redirect()->route('AddOperator')->with('success', 'Operator added successfully');
}

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

     public function updateStatus(Request $request)
    {
        $operator = Operator::findOrFail($request->id);

        $operator->status = $request->has('status') ? 1 : 0 ;
        $operator->save();

        return back()->with('success', 'Status updated!');
    }
}

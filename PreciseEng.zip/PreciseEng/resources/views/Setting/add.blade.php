@extends('layouts.header')
@section('content')

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">

            <!-- 🔵 Add Setting Form -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card shadow-sm">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Add Setting</h5>
                        </div>
                        <div class="card-body">
                            @if(session('success'))
                                <div class="alert alert-success">{{ session('success') }}</div>
                            @endif

                            <form action="{{ route('storeSetting') }}" method="POST">
                                @csrf
                                <div class="row mb-3">
                                    <label for="setting_name" class="col-sm-2 col-form-label">Setting Name <span class="mandatory">*</span></label>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control" id="setting_name" name="setting_name" value="{{ old('setting_name') }}" placeholder="Enter Setting Name" required>
                                        @error('setting_name')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>
                                    <div class="col-sm-4">
                                        <button type="submit" class="btn btn-primary">Add Setting</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 🔵 Setting List Table -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card shadow-sm">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Setting List</h5>
                        </div>
                        <div class="card-body">
                            @if($settings->count())
                                <div class="table-responsive">
                                   <table id="buttons-datatables" class="display table table-bordered" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No.</th>
                                                <th>Setting Name</th>
                                                <th>Status</th>

                                                <th width="12%">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($settings as $set)
                                                <tr>
                                                    <td>{{ $loop->iteration }}</td>
                                                    <td>{{ $set->setting_name }}</td>

                                                     <td>
                                                <form action="{{ route('updateStatus') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="id" value="{{ $set->id }}">
                                                    <div class="form-check form-switch">
                                                        <input
                                                            class="form-check-input"
                                                            type="checkbox"
                                                            role="switch"
                                                            id="statusSwitch{{ $set->id }}"
                                                            name="status"
                                                            value="1"
                                                            onchange="this.form.submit()"
                                                            {{ $set->status == 1 ? 'checked' : '' }}>
                                                  
                                                    </div>
                                                </form>

                                            </td>
                                                    <td>
                                                        <a href="{{route('editSetting', base64_encode($set->id))}}">
                                                            <button type="button" class="btn btn-success btn-icon waves-effect waves-light">
                                                                <i class="ri-pencil-fill align-bottom"></i>
                                                            </button>
                                                        </a>

                                                        <a href="">
                                                            <button type="button" class="btn btn-primary btn-icon waves-effect waves-light">
                                                                <i class="ri-eye-fill align-bottom"></i>
                                                            </button>
                                                        </a>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            @else
                                <p class="text-muted">No Settings found.</p>
                            @endif
                        </div>
                    </div>
                </div>
            </div>

        </div> 
    </div> 
</div> 

@endsection

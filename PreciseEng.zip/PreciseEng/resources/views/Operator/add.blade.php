@extends('layouts.header')
@section('content')

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">

            <!--  Operator Add Form -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card shadow-sm">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Add Operator</h5>
                        </div>
                        <div class="card-body">
                            @if(session('success'))
                                <div class="alert alert-success">{{ session('success') }}</div>
                            @endif

                            <form action="{{ route('storeOperator') }}" method="POST">
                                @csrf
                                <div class="row mb-3">
                                    <label for="operator_name" class="col-sm-2 col-form-label">Operator Name<span class="mandatory">*</span></label>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control" id="operator_name" name="operator_name" value="{{ old('operator_name') }}" placeholder="Enter Operator Name" required>
                                        @error('operator_name')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>
                                    <div class="col-sm-4">
                                        <button type="submit" class="btn btn-primary">Add Operator</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!--  Operator List Table -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card shadow-sm">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Operators List</h5>
                        </div>
                        <div class="card-body">
                            @if($operators->count())
                                <div class="table-responsive">
                                    <table id="buttons-datatables" class="display table table-bordered" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No.</th>
                                                <th>Operator Name</th>
                                               <th width="12%">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($operators as $op)
                                                <tr>
                                                    <td>{{ $loop->iteration }}</td>
                                                    <td>{{ $op->operator_name }}</td>

                                                        <td>
                                                     <form action="{{ route('updateStatus') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="id" value="{{ $op->id }}">
                                                    <div class="form-check form-switch">
                                                        <input
                                                            class="form-check-input"
                                                            type="checkbox"
                                                            role="switch"
                                                            id="statusSwitch{{ $op->id }}"
                                                            name="status"
                                                            value="1"
                                                            onchange="this.form.submit()"
                                                            {{ $op->status == 1 ? 'checked' : '' }}>
                                                  
                                                    </div>
                                                </form>

                                            </td>
                                                    <td>
                                                        <a href="#">
                                                            <button type="button" class="btn btn-success btn-icon waves-effect waves-light">
                                                                <i class="ri-pencil-fill align-bottom"></i>
                                                            </button>
                                                        </a>

                                                        <button type="button" class="btn btn-primary btn-icon waves-effect waves-light">
                                                            <i class="ri-eye-fill align-bottom"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            @else
                                <p class="text-muted">No operators found.</p>
                            @endif
                        </div>
                    </div>
                </div>
            </div>

        </div> <!-- container-fluid -->
    </div> <!-- page-content -->
</div> <!-- main-content -->

@endsection


<?php $__env->startSection('content'); ?>

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">View Vendors</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="buttons-datatables" class="display table table-bordered" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>Sr No.</th>
                                            <th>Vendor Name</th>
                                            <th>Vendor Code</th>
                                            <th>Contact Person</th>
                                            <th>Phone No.</th>
                                            <th>Email ID</th>
                                            <th>GST No.</th>
                                            <th>Address</th>
                                            <th>Status</th>
                                            <th width="12%">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($vendor->vendor_name); ?></td>
                                            <td><?php echo e($vendor->vendor_code); ?></td>
                                            <td><?php echo e($vendor->contact_person); ?></td>
                                            <td><?php echo e($vendor->phone_no); ?></td>
                                            <td><?php echo e($vendor->email_id); ?></td>
                                            <td><?php echo e($vendor->gst_no ?? 'N/A'); ?></td>
                                            <td><?php echo e($vendor->address); ?></td>
                                            <td>
                                                <?php if($vendor->status == 'Active'): ?>
                                                    <span class="badge bg-success">Active</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Inactive</span>
                                                <?php endif; ?>
                                            </td>

                                             <td>
                                           
                                             <a href="<?php echo e(route('editVendor', base64_encode($vendor->id))); ?>">
                                                    <button type="button" class="btn btn-success btn-icon waves-effect waves-light">
                                                        <i class="ri-pencil-fill align-bottom"></i>
                                                    </button>
                                                </a>

                                                <button type="button" class="btn btn-primary btn-icon waves-effect waves-light">
                                                    <i class="ri-eye-fill align-bottom"></i>
                                                </button>

                                                <button type="button" class="btn btn-danger btn-icon waves-effect waves-light">
                                                    <i class="ri-delete-bin-fill align-bottom"></i>
                                                </button>
                                            </td>

                                           
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--end row-->

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PreciseEng\resources\views/Vendor/view.blade.php ENDPATH**/ ?>
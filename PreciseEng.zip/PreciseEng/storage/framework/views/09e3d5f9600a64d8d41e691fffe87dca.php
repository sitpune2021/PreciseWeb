
<?php $__env->startSection('content'); ?>

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-xxl-12">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="mb-0 flex-grow-1">  <?php echo e(isset($workorder) ? 'Edit WorkOrder' : 'Add Work Order'); ?></h4>
                        </div>

                        <div class="card-body">
                            <div class="live-preview">
                            <form action="<?php echo e(isset($workorder) ? route('updateWorkEntry', base64_encode($workorder->id)) : route('storeWorkEntry')); ?>" method="POST">

                                    <?php echo csrf_field(); ?>
                                    <?php if(isset($workorder)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="work_order_no" class="form-label">Work Order No <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="work_order_no" name="work_order_no" placeholder="Work Order No" value="<?php echo e(old('work_order_no', $workorder->work_order_no ?? '')); ?>">
                                                <?php $__errorArgs = ['work_order_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="entry_code" class="form-label">Entry Code <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="entry_code" name="entry_code" placeholder="Entry Code" value="<?php echo e(old('entry_code', $workorder->entry_code ?? '')); ?>">
                                                <?php $__errorArgs = ['entry_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>


                                             <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="part" class="form-label">Part <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="part" name="part" placeholder="Enter Part" value="<?php echo e(old('part', $workorder->part ?? '')); ?>">
                                                <?php $__errorArgs = ['part'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="date" class="form-label">Date <span class="mandatory">*</span></label>
                                                <input type="date" class="form-control" id="date" name="date" value="<?php echo e(old('date', $workorder->date ?? '')); ?>">
                                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="part_code" class="form-label">Part Code <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="part_code" name="part_code" placeholder="Part Code" value="<?php echo e(old('part_code', $workorder->part_code ?? '')); ?>">
                                                <?php $__errorArgs = ['part_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="dimeter" class="form-label">Diameter <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="dimeter" name="dimeter" placeholder="Diameter" value="<?php echo e(old('dimeter', $workorder->dimeter ?? '')); ?>">
                                                <?php $__errorArgs = ['dimeter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="length" class="form-label">Length <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="length" name="length" placeholder="Length" value="<?php echo e(old('length', $workorder->length ?? '')); ?>">
                                                <?php $__errorArgs = ['length'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="width" class="form-label">Width <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="width" name="width" placeholder="Width" value="<?php echo e(old('width', $workorder->width ?? '')); ?>">
                                                <?php $__errorArgs = ['width'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="height" class="form-label">Height <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="height" name="height" placeholder="Height" value="<?php echo e(old('height', $workorder->height ?? '')); ?>">
                                                <?php $__errorArgs = ['height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="exp_time" class="form-label">Expected Time <span class="mandatory">*</span></label>
                                                <input type="time" class="form-control" id="exp_time" name="exp_time" value="<?php echo e(old('exp_time', $workorder->exp_time ?? '')); ?>">
                                                <?php $__errorArgs = ['exp_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="quantity" class="form-label">Quantity <span class="mandatory">*</span></label>
                                                <input type="number" class="form-control" id="quantity" name="quantity" placeholder="Quantity" value="<?php echo e(old('quantity', $workorder->quantity ?? '')); ?>">
                                                <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <label for="part_description" class="form-label">Part Description <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="part_description" name="part_description" placeholder="Description" value="<?php echo e(old('part_description', $workorder->part_description ?? '')); ?>">
                                                <?php $__errorArgs = ['part_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="text-end">
                                                <button type="submit" class="btn btn-primary"><?php echo e(isset($workorder) ? 'Update' : 'Submit'); ?></button>
                                                &nbsp;
                                                <?php if(isset($workorder)): ?>
                                                <a href="<?php echo e(route('ViewWorkOrder')); ?>" class="btn btn-info">Cancel</a>
                                                <?php else: ?>
                                                <button type="reset" class="btn btn-info">Reset</button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div><!-- end row -->
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div><!-- end row -->

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PreciseEng\resources\views/WorkOrder/add.blade.php ENDPATH**/ ?>
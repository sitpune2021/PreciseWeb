
<?php $__env->startSection('content'); ?>

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-12">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="mb-0 flex-grow-1">
                                <?php echo e(isset($project) ? 'Edit Project' : 'Add Project'); ?>

                            </h4>
                        </div><!-- end card header -->

                        <div class="card-body">
                            <div class="live-preview">
                                <form action="<?php echo e(isset($project) ? route('updateProject', base64_encode($project->id)) : route('storeProject')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php if(isset($project)): ?>
                                    <?php echo method_field('PUT'); ?>
                                    <?php endif; ?>

                                    <div class="row">
                                        <!-- Project Name -->
                                        <!-- <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="name" class="form-label">Project Name <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="name" name="name" placeholder="Project Name" value="<?php echo e(old('name', $project->name ?? '')); ?>">
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div> -->

                                        <!-- Project Code -->
                                        <!-- <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="code" class="form-label">Project Code <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="code" name="code" placeholder="Project Code" value="<?php echo e(old('code', $project->code ?? '')); ?>">
                                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
  -->
                                        <div class="col-md-6">
                                            <div class="mb-3">

                                                <?php
                                                $codes = DB::select('SELECT id, code, name FROM customers');
                                    
                                                ?>
                                                <label for="code" class="form-label">Customer Name <span class="mandatory">*</span></label>
                                                <select class="form-select" id="code" name="code">
                                                    <option value="">Select Customer </option>
                                                    <?php $__currentLoopData = $codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </select>
                                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-red"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <!-- Work Order No -->
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="work_order_no" class="form-label">Work Order No. <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="work_order_no" name="work_order_no" placeholder="Work Order Number" value="<?php echo e(old('work_order_no', $project->work_order_no ?? '')); ?>">
                                                <?php $__errorArgs = ['work_order_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>



                                        <!-- Quantity -->
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="qty" class="form-label">Quantity <span class="mandatory">*</span></label>
                                                <input type="number" step="any" class="form-control" id="qty" name="qty" placeholder="Quantity" value="<?php echo e(old('qty', $project->qty ?? '')); ?>">
                                                <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>



                                        <!-- Start Date -->
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="StartDate" class="form-label">Start Date</label>
                                                <input type="date" class="form-control" id="StartDate" name="StartDate" value="<?php echo e(old('StartDate', isset($project->StartDate) ? \Carbon\Carbon::parse($project->StartDate)->format('Y-m-d') : '')); ?>">
                                                <?php $__errorArgs = ['StartDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <!-- End Date -->
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="EndDate" class="form-label">End Date</label>
                                                <input type="date" class="form-control" id="EndDate" name="EndDate" value="<?php echo e(old('EndDate', isset($project->EndDate) ? \Carbon\Carbon::parse($project->EndDate)->format('Y-m-d') : '')); ?>">
                                                <?php $__errorArgs = ['EndDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <!-- Project Description -->
                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <label for="description" class="form-label">Project Description <span class="mandatory">*</span></label>
                                                <textarea class="form-control" id="description" name="description" placeholder="Project Description"><?php echo e(old('description', $project->description ?? '')); ?></textarea>
                                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <!-- Submit Button -->
                                        <div class="col-lg-12">
                                            <div class="text-end">
                                                <button type="submit" class="btn btn-primary">
                                                    <?php echo e(isset($project) ? 'Update' : 'Submit'); ?>

                                                </button>
                                                &nbsp;
                                                <?php if(isset($project)): ?>
                                                <a href="<?php echo e(route('ViewProject')); ?>" class="btn btn-info">Cancel</a>
                                                <?php else: ?>
                                                <button type="reset" class="btn btn-info">Reset</button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<!-- Dropdown -->
<div class="col-md-6">
    <div class="mb-3">
        <label for="code" class="form-label">Customer Code <span class="mandatory">*</span></label>
        <select class="form-control" id="code" name="code">
            <option value="">Select Customer Code</option>
        </select>
        <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-red"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PreciseEng\resources\views/Project/add.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-12">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="mb-0 flex-grow-1">
                                <?php echo e(isset($vendor) ? 'Edit Vendor' : 'Add Vendor'); ?>

                            </h4>
                        </div>

                        <div class="card-body">
                            <div class="live-preview">
                                <form action="<?php echo e(route('storeVendor')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <div class="row">

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="vendor_name" class="form-label">Vendor Name <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="vendor_name" name="vendor_name" placeholder="Vendor Name" value="<?php echo e(old('vendor_name', $vendor->vendor_name ?? '')); ?>">
                                                <?php $__errorArgs = ['vendor_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="vendor_code" class="form-label">Vendor Code <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="vendor_code" name="vendor_code" placeholder="Vendor Code" value="<?php echo e(old('vendor_code', $vendor->vendor_code ?? '')); ?>">
                                                <?php $__errorArgs = ['vendor_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="contact_person" class="form-label">Contact Person <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="contact_person" name="contact_person" placeholder="Contact Person" value="<?php echo e(old('contact_person', $vendor->contact_person ?? '')); ?>">
                                                <?php $__errorArgs = ['contact_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="gst_no" class="form-label">GST No <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="gst_no" name="gst_no" placeholder="GST Number" value="<?php echo e(old('gst_no', $vendor->gst_no ?? '')); ?>">
                                                <?php $__errorArgs = ['gst_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="phone_no" class="form-label">Phone No <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="phone_no" name="phone_no" placeholder="Phone Number" value="<?php echo e(old('phone_no', $vendor->phone_no ?? '')); ?>">
                                                <?php $__errorArgs = ['phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="email_id" class="form-label">Email ID</label>
                                                <input type="email" class="form-control" id="email_id" name="email_id" placeholder="Email ID" value="<?php echo e(old('email_id', $vendor->email_id ?? '')); ?>">
                                                <?php $__errorArgs = ['email_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                     <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="statusToggle" class="form-label">Status <span class="mandatory">*</span></label><br>
                                                <div class="form-check form-switch">
                                                    <input 
                                                        class="form-check-input" 
                                                        type="checkbox" 
                                                        id="statusToggle" 
                                                        name="status" 
                                                        value="Active"
                                                        <?php echo e(old('status', $vendor->status ?? 'Active') == 'Active' ? 'checked' : ''); ?>

                                                        onchange="this.value = this.checked ? 'Active' : 'Inactive'"
                                                    >
                                                    <label class="form-check-label" for="statusToggle">
                                                        <?php echo e(old('status', $vendor->status ?? 'Active') == 'Active' ? 'Active' : 'Inactive'); ?>

                                                    </label>
                                                </div>
                                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>


                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <label for="address" class="form-label">Address <span class="mandatory">*</span></label>
                                                <textarea class="form-control" id="address" name="address" placeholder="Address..."><?php echo e(old('address', $vendor->address ?? '')); ?></textarea>
                                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="text-end">
                                                <button type="submit" class="btn btn-primary"><?php echo e(isset($vendor) ? 'Update' : 'Submit'); ?></button>
                                                &nbsp;
                                                <?php if(isset($vendor)): ?>
                                                <a href="<?php echo e(route('ViewVendor')); ?>" class="btn btn-info">Cancel</a>
                                                <?php else: ?>
                                                <button type="reset" class="btn btn-info">Reset</button>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div><!-- end row -->
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div><!-- end row -->
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PreciseEng\resources\views/Vendor/add.blade.php ENDPATH**/ ?>
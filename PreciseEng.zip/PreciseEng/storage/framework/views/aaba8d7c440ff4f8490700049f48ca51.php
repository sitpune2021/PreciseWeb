
<?php $__env->startSection('content'); ?>

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-12">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="mb-0 flex-grow-1">
                                <?php echo e(isset($client) ? 'Edit Client' : 'Add Client'); ?>

                            </h4>
                        </div>

                        <div class="card-body">
                            <div class="live-preview">
                                <form action="<?php echo e(isset($client) ? route('updateClient', base64_encode($client->id)) : route('storeClient')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php if(isset($client)): ?>
                                        <?php echo method_field('PUT'); ?>
                                    <?php endif; ?>

                                    <div class="row">

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="name" class="form-label">Client Name <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="name" name="name" placeholder="Client Name" value="<?php echo e(old('name', $client->name ?? '')); ?>">
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="email_id" class="form-label">Email ID</label>
                                                <input type="email" class="form-control" id="email_id" name="email_id" placeholder="Email Id" value="<?php echo e(old('email_id', $client->email_id ?? '')); ?>">
                                                <?php $__errorArgs = ['email_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="phone_no" class="form-label">Phone No <span class="mandatory">*</span></label>
                                                <input type="text" class="form-control" id="phone_no" name="phone_no" placeholder="Phone Number" value="<?php echo e(old('phone_no', $client->phone_no ?? '')); ?>">
                                                <?php $__errorArgs = ['phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="gst_no" class="form-label">GST No <span class="mandatory">*</span></label>

                                                <input type="text" class="form-control" id="gst_no" name="gst_no" placeholder="GST Number" value="<?php echo e(old('gst_no', $client->gst_no ?? '')); ?>">
                                                <?php $__errorArgs = ['gst_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-4">
                                                <div class="mb-3">
                                                    <label for="logo" class="form-label">Client Logo <?php echo e(isset($client) ? '' : '*'); ?></label>
                                                    <input type="file" class="form-control" id="logo" name="logo">

                                                    <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <?php if(isset($client) && $client->logo): ?>
                                                <div class="col-md-2">
                                                    <div class="mb-3">
                                                        <img src="<?php echo e(asset($client->logo)); ?>" alt="Logo" width="100">
                                                    </div>
                                                </div>
                                            <?php endif; ?>


                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <label for="address" class="form-label">Address <span class="mandatory">*</span></label>
                                                <textarea class="form-control" id="address" name="address" placeholder="Address..."><?php echo e(old('address', $client->address ?? '')); ?></textarea>
                                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="text-end">
                                                <button type="submit" class="btn btn-primary"><?php echo e(isset($client) ? 'Update' : 'Submit'); ?></button>
                                                &nbsp;
                                                <?php if(isset($client)): ?>
                                                    <a href="<?php echo e(route('ViewClient')); ?>" class="btn btn-info">Cancel</a>
                                                <?php else: ?>
                                                    <button type="reset" class="btn btn-info">Reset</button>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div><!-- end row -->
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div><!-- end row -->
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PreciseEng\resources\views/Client/add.blade.php ENDPATH**/ ?>
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\CustomerContoller;
use App\Http\Controllers\VendorContoller;
use App\Http\Controllers\ClientContoller;
use App\Http\Controllers\WorkOrderController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\OperatorController;
use App\Http\Controllers\MachineController;
use App\Http\Controllers\SettingController;





Auth::routes();
Route::middleware(['auth'])->group(function () {
 
Route::get('/'                  , [HomeController::class, 'index'])->name('home');
});

Route::get('/superAdmin'        , [HomeController::class, 'superAdmin'])->name('superAdmin');
Route::get('logout'             , [HomeController::class, 'logout'])->name('logout');
 

Route::get('/AddClient'          , [ClientContoller::class, 'AddClient'])->name('AddClient');
Route::get('/ViewClient'         , [ClientContoller::class, 'ViewClient'])->name('ViewClient');
Route::post('/storeClient'       ,[ClientContoller::class, 'storeClient'])->name('storeClient');
Route::get('/editClient/{id}'    , [ClientContoller::class, 'edit'])->name('editClient');
Route::put('/updateClient/{id}'  , [ClientContoller::class, 'update'])->name('updateClient');
 


Route::get('/AddCustomer'               , [CustomerContoller::class, 'AddCustomer'])->name('AddCustomer');
Route::get('/ViewCustomer'              , [CustomerContoller::class, 'ViewCustomer'])->name('ViewCustomer');
Route::post('/storeCustomer'            , [CustomerContoller::class, 'storeCustomer'])->name('storeCustomer');
Route::get('/editCustomer/{id}'         , [CustomerContoller::class, 'edit'])->name('editCustomer');
Route::put('/updateCustomer/{id}'       , [CustomerContoller::class, 'update'])->name('updateCustomer');


Route::get('/AddVendor'         , [VendorContoller::class, 'AddVendor'])->name('AddVendor');
Route::post('/storeVendor'      , [VendorContoller::class, 'storeVendor'])->name('storeVendor');
Route::get('/ViewVendor'         , [VendorContoller::class, 'ViewVendor'])->name('ViewVendor');
Route::get('/editVendor/{id}'    , [VendorContoller::class, 'edit'])->name('editVendor');
Route::put('/updateVendor/{id}'  , [VendorContoller::class, 'update'])->name('updateVendor');

// AddWorkOrder

Route::get('/AddWorkOrder'          , [WorkOrderController::class, 'AddWorkOrder'])->name('AddWorkOrder');
Route::get('/ViewWorkOrder'         , [WorkOrderController::class, 'ViewWorkOrder'])->name('ViewWorkOrder');
Route::post('/storeWorkEntry'       ,[WorkOrderController::class, 'storeWorkEntry'])->name('storeWorkEntry');
Route::get('/editWorkOrder/{id}'    , [WorkOrderController::class, 'edit'])->name('editWorkOrder');
Route::put('/updateWorkEntry/{id}'  , [WorkOrderController::class, 'update'])->name('updateWorkEntry');



Route::get('/AddProject'                 ,[ProjectController::class, 'AddProject'])->name('AddProject');
Route::get('/ViewProject'                ,[ProjectController::class, 'ViewProject'])->name('ViewProject');
Route::post('/storeProject'              ,[ProjectController::class, 'storeProject'])->name('storeProject');
Route::get('/editProject/{id}'           ,[ProjectController::class, 'edit'])->name('editProject');
Route::put('/updateProject/{id}'         ,[ProjectController::class, 'update'])->name('updateProject');


Route::get('/AddOperator'                 ,[OperatorController::class, 'AddOperator'])->name('AddOperator');
Route::post('/storeOperator'              ,[OperatorController::class, 'storeOperator'])->name('storeOperator');
Route::post('updateStatus'              ,[OperatorController::class, 'updateStatus'])->name('updateStatus');



Route::get('/AddMachine'                 ,[MachineController::class, 'AddMachine'])->name('AddMachine');
Route::post('/storeMachine'              ,[MachineController::class, 'storeMachine'])->name('storeMachine');
Route::post('updateStatus'              ,[MachineController::class, 'updateStatus'])->name('updateStatus');

Route::get('/AddSetting'                 ,[SettingController::class, 'AddSetting'])->name('AddSetting');
Route::post('/storeSetting'              ,[SettingController::class, 'storeSetting'])->name('storeSetting');
Route::get('/editSetting/{id}'           ,[SettingController::class, 'editSetting'])->name('editSetting');
Route::post('/updateSetting'              ,[SettingController::class, 'updateSetting'])->name('updateSetting');
Route::post('updateStatus'              ,[SettingController::class, 'updateStatus'])->name('updateStatus');

























